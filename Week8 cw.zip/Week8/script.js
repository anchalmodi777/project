console.log('Is this file connected?');

// // // filter example

// // const students = ['Javi', 'Maria', 'Rhona', 'Jack', 'Alex', 'Ibra'];

// // // const filteringFunction = (element) => {
// // //   console.log(element);
// // //   return element.includes('r');
// // // };

// // const studentsWithR = students.filter((element) => {
// //   // 1st iteration:
// //   // element = 'Rhona'
// //   // element.toLowerCase() = 'rhona'
// //   console.log(element);
// //   return element.toLowerCase().includes('r');
// // });

// // // ['Maria', 'Ibra', 'Rhona']

// // console.log(studentsWithR);

// // // Map method

// // const productPrices = [23, 34, 66, 10, 1];

// // // const increasedPrices = productPrices.map((productPrice) => {
// // //   // Only increase if the price is lower or equal than 30
// // //   let newPrice = productPrice;
// // //   if (productPrice <= 30) {
// // //     newPrice = productPrice * 1.1;
// // //   }

// // //   return newPrice;
// // // });

// // const increasedPrices = productPrices.map((productPrice) => {
// //   // Only increase if the price is lower or equal than 30
// //   if (productPrice <= 30) {
// //     productPrice = productPrice * 1.1;
// //   }

// //   return productPrice;
// // });

// // console.log(increasedPrices);

// // // HOMEWORK

// // const menuDatabase = [
// //   ['Papadum', 20, 'vegetarian'],
// //   ['Pakora', 50, 'meat'],
// //   ['Tandoori Chicken', 60, 'meat'],
// //   ['Samosa', 50, 'vegetarian'],
// //   ['Butter Chicken', 139, 'meat'],
// //   ['Chicken Korma', 129, 'meat'],
// //   ['Chicken Vindaloo', 149, 'meat'],
// //   ['Saag Lamb', 130, 'meat'],
// //   ['Lam Tikka Masala', 159, 'meat'],
// //   ['Yellow Daal Tadka', 119, 'vegetarian'],
// //   ['Biryani', 129, 'vegetarian'],
// //   ['Gulab Jamun', 55, 'dessert'],
// //   ['Mango Kulfi', 35, 'dessert'],
// //   ['Rasmalai', 60, 'dessert'],
// // ];

// // // After some months of your restaurant being open, you realised
// // // that the last element in the menu hasn’t been sold in the last 4
// // // months so you decide to remove it from the menu, use an array method
// // // to remove the last element of an array and save it in a variable
// // // called: removedMenuItem.

// // const removedMenuItem = menuDatabase.pop();
// // console.log('removed dish:', removedMenuItem);
// // console.log('menuDatabase after removal', menuDatabase);

// // const newDatabase = menuDatabase.filter((menuItem) => {
// //   // menuItem = ['Rasmalai', 60, 'dessert']

// //   // if name of element === 'Rasmalai', filter it out!
// //   // menuItem[0] = 'Rasmalai'
// //   return menuItem[0] !== 'Rasmalai';
// // });

// // console.log('newDatabase', newDatabase);

// // // Due to inflation you have gone through your finances and you
// // // realised that you need to increase all the menu prices by 10%.
// // // To do this we want to create a new array (called increasedMenuDatabase)
// // // \containing all the menu items with the mentioned price increase.
// // //  Hint: Use the ‘map’ method.

// // const increasedMenuDatabase = newDatabase.map((menuItem) => {
// //   // 1st iteration
// //   // menuItem = ['Papadum', 20, 'vegetarian']
// //   menuItem[1] = 1.1 * menuItem[1];
// //   // menuItem = ['Papadum', 22, 'vegetarian']

// //   // 2nd iteration
// //   // menuItem = ['Pakora', 50, 'meat'],
// //   // menuItem[1] = 1.1 * menuItem[1];
// //   // menuItem = ['Pakora', 55, 'meat'],

// //   return menuItem;
// // });

// // console.log('increasedMenuDatabase', increasedMenuDatabase);

// // // A customer asks you about how many vegetarian dishes you have in the
// // // menu, for this you might want to filter the menu and get the amount of
// // // items filtered by the type: ‘vegetarian’. Call this
// // // variable: amountVegetariantDishes.

// // const vegetarianDishes = increasedMenuDatabase.filter((dish) => {
// //   // dish = ['Pakora', 55, 'meat'],
// //   return dish.includes('vegetarian');
// // });

// // console.log(vegetarianDishes);

// // console.log(vegetarianDishes.length);

// // // For loops

// const colors = ['red', 'yellow', 'white', 'black'];

// for (let x = 0; x < colors.length; x++) {
//   console.log('I am inside of the for loop');
//   console.log('x equals', x);
//   console.log(colors[x]);

//   // 1st iteration: x = 0 | colors[0] = 'red'
//   // 2nd iteration: x = 1 | colors[1] = 'yellow'
//   // 3rd iteration: x = 2 | colors[2] = 'white'
//   // 4th iteration: x = 3 | colors[3] = 'black'
//   // 5th iteration: x = 4 | colors[4] = undefined
// }

// // 1st iteration x = 0 -> RUN!
// // 2nd iteration x = 1 -> RUN!
// // 3rd iteration x = 2 -> STOP!

// // const shopNames = ['matas', 'normal', 'netto'];

// for (let i = 0; i < shopNames.length; i++) {
//   console.log(shopNames[i]);
// }

// For-of loops
// const shopNames = ['matas', 'normal', 'netto'];
// for (let i of shopNames) {
//   console.log(i);
// }

// Exercise
const menuDatabase = [
  ['Papadum', 20, 'vegetarian'],
  ['Pakora', 50, 'meat'],
  ['Tandoori Chicken', 60, 'meat'],
  ['Samosa', 50, 'vegetarian'],
  ['Butter Chicken', 139, 'meat'],
  ['Chicken Korma', 129, 'meat'],
  ['Chicken Vindaloo', 149, 'meat'],
  ['Saag Lamb', 130, 'meat'],
  ['Lam Tikka Masala', 159, 'meat'],
  ['Yellow Daal Tadka', 119, 'vegetarian'],
  ['Biryani', 129, 'vegetarian'],
  ['Gulab Jamun', 55, 'dessert'],
  ['Mango Kulfi', 35, 'dessert'],
  ['Rasmalai', 60, 'dessert'],
];

for (let menuItem of menuDatabase) {
  // 1st iteration name = ['Papadum', 20, 'vegetarian']
  const name = menuItem[0];
  // const name = document.createTextNode(menuItem[0]);
  console.log(name);

  // a. Create a <li> element
  const liElement = document.createElement('li');

  // b. Add the dish name to the innerHtml of the element
  liElement.innerText += name;
  // liElement.appendChild(name);

  // c. Append the element to the <ul> created above
  const ulElement = document.querySelector('#menu-container');
  ulElement.append(liElement);
}
